<?php
define('DEBUG',true);

define('DB_NAME','madmvc');
define('DB_USER','root1');
define('DB_PASS','root');
define('DB_HOST','127.0.0.1');


define('DEFAULT_CONTROLLER','Redirect'); // def controller
define('DEFAULT_LAYOUT','default');// if no layout is iset in the controller use this one.

define('PROOT','/');// set this to '/' for live server;
define('SITE_URL','localhost/');
define('SITE_TITLE','MadMax MVC Framework'); // This will be used if no site title;

define('CURRENT_USER_SESSION_NAME','SdasdAddasdasdasdasdAasscxgefvfev');
define('REMEMBER_USER_COOKIE_NAME','kSdeZclpsdevgrewAAswfevx');
define('REMEMBER_ME_EXPIRY',2592000);

define('ACCESS_RESTRICTED','Restricted');
define('SITE_BRAND','AdminPanel');