<?php $this->start('body'); ?>
<h1 class="text-center red">This is Index </h1>
<?php $this->end(); ?>