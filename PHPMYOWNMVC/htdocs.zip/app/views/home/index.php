<?php $this->start('head'); ?>

<?php $this->end(); ?>
<?php $this->start('body'); ?>

<?php $this->end(); ?> 

