<?php $this->start('body'); ?>
<h1> Denied</h1>
<?php $this->end(); ?> 

