<?php $this->start('body'); 
echo array('conditions'=>"a");
$this->end(); ?> 